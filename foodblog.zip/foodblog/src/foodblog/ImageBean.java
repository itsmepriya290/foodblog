package foodblog;

public class ImageBean {
	
	//private PostBean post;
	private String url;
	private int id;
	
//	public PostBean getPost()
//	{
//		return post;
//	}
//	
//	public void setPost(PostBean newPost)
//	{
//		post=newPost;
//	}
	
	public String getUrl()
	{
		return url;
	}
	
	public void setUrl(String newUrl)
	{
		url=newUrl;
	}
	
	public int getId()
	{
		return id;
	}
	
	public void setId(int newId)
	{
		id=newId;
	}

}
