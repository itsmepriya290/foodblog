package foodblog;

public class LikesBean {
	
	//private PostBean post;
	private UserBean user;
	private int id;
	
//	public PostBean getPost()
//	{
//		return post;
//	}
//	
//	public void setPost(PostBean newPost)
//	{
//		post=newPost;
//	}
	
	public UserBean getUser()
	{
		return user;
	}
	
	public void setUser(UserBean newUser)
	{
		user=newUser;
	}
	
	public int getId()
	{
		return id;
	}
	
	public void setId(int newId)
	{
		id=newId;
	}

}
