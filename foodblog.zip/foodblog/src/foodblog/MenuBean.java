package foodblog;

public class MenuBean {
	
    private String name;
    private double price;
   
	
    public String getName() {
       return name;
	}

    public void setName(String newName) {
       name = newName;
	}

			

    public double getPrice() {
       return price;
	}

    public void setPrice(double newPrice) {
       price = newPrice;
	}
	
			
    
}
